<?php get_header(); ?>
<div  <?php post_class('member-item-wrapper center-relative'); ?>>
    <?php
		require ('ajax-single-team.php');
    ?>
</div>
<?php get_footer(); ?>